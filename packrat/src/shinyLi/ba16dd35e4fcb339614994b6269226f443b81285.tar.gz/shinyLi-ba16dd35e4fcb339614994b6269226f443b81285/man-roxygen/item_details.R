#'@details
#'See \link{<%=family_name %>} for more information about how to use \code{<%=item_name %>} with the
#'rest of the <%=family_name %> family.
