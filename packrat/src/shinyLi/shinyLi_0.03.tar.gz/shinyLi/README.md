shinyLi
-------

**shinyLi** is a package that ...

```R
install.packages("devtools")
```

```R
devtools::install_github("lsgsb/shinyLi", host="github.uc.edu/api/v3", auth_token="...”)
```

Original source for the visualizations:
http://lincs.hms.harvard.edu/explore/10.1038-nchembio.1337/fallahi-sichani-2013/
