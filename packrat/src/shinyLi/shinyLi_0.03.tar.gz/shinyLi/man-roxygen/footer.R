#'@seealso \href{http://}{HMS}
#'
#'@note
#' Run \code{liExample("<%=family_name %>")} for an example
#' of \code{<%=item_name %>} functionality.
#' 
#'@family <%=family_name %>
#'@name <%=item_name %>
